## 🚀 Welcome to the PayFit live coding challenge

### 🖥 Context

In this challenge, you're working within an Operating System environment where filesystem paths are managed in a `registry`. The filesystem is represented by an array of `directories`, with each directory object detailing its location, parent.

### 📘 Rules

Your solutions should be implemented in `index.js`, which will contain all your exported functions. It's crucial to design your functions with reusability in mind, as they will be leveraged across multiple tasks within this challenge.

### 🧪 Unit Testing

Unit tests are a critical part of this coding challenge. You will find a file named `exercice1.test.js` in your workspace, which contains tests for the functions you are to implement. Ensure your functions pass all the tests provided and consider writing additional tests to cover edge cases and ensure robustness.

### ☑️ Your Tasks

#### Create a function returning all the absolute paths

- **Function to Implement**: `getAllPaths(directories)`
- **Expected Output**: An array of string, which represents the full path to the directory.
- **Unit Testing**: Ensure your function passes all tests in `exercice1.test.js` related to this task. Consider edge cases such as empty directories or invalid inputs.

### 📝 Note

While implementing your solutions, keep in mind the importance of clean, readable, and efficient code. Your ability to write code that not only works but is also maintainable and testable will be a key aspect of this challenge.
