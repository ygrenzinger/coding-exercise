export interface Directory {
  name: string;
  parent: string | null;
}
