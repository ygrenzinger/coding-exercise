import { Directory } from "./types";

/**
 * Create a list of all absolute paths
 */
export const getAllPaths = (directories: Directory[]): string[] => {
  // you need to fill this
  return [];
};
