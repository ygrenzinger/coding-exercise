import { getAllPaths } from './'
import { Directory } from './types'

const directories: Directory[] = [
  {
    name: 'projects',
    parent: null,
  },
  {
    name: 'photos',
    parent: null,
  },
  {
    name: 'laboratory',
    parent: 'projects',
  },
  {
    name: 'john',
    parent: 'projects',
  },
  {
    name: 'secret',
    parent: 'projects',
  },
  {
    name: 'rocket',
    parent: 'secret',
  },
  {
    name: 'before',
    parent: 'after',
  },
  {
    name: 'after',
    parent: null,
  },
  {
    name: 'level1',
    parent: null,
  },
  {
    name: 'level2',
    parent: 'level1',
  },
  {
    name: 'level3',
    parent: 'level2',
  },
  {
    name: 'level4',
    parent: 'level3',
  },
]

describe('Get all paths', () => {
  it('should have correct length', () => {
    const paths = getAllPaths(directories)

    expect(paths).toHaveLength(12)
  })

  it.each([
    '/projects',
    '/photos',
    '/projects/laboratory',
    '/projects/john',
    '/projects/secret',
    '/projects/secret/rocket',
    '/after',
    '/after/before',
    '/level1',
    '/level1/level2',
    '/level1/level2/level3',
    '/level1/level2/level3/level4',
  ])('should return the path %s', (expectedPath) => {
    const mDirectories = getAllPaths(directories)

    expect(mDirectories).toContain(expectedPath)
  })
})
